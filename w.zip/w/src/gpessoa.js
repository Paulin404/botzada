const gpessoa = (prefix) => {

return `*GERADORE DE DADOS PESSOAIS:*

*VRAU LS* HEHEHEHE

OFF


`
}
exports.gpessoa = gpessoa
